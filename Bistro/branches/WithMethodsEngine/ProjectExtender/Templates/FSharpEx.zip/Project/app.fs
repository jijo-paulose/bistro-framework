#light

namespace $safeprojectname$

    open System
    module $safeitemname$ =
                
        let defaultC (ctx: ictx) = () 
