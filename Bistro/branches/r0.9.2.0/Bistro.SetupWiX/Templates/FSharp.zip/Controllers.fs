//Basic FSharp Bistro controller.
//You can find the example of Bistro FSharp application here:
//https://bistro-framework.googlecode.com/svn/Examples/MvcSamplePortFS/trunk

#light

namespace BistroApp32

    open Bistro.FS.Controller
    open Bistro.FS.Definitions
    open Bistro.FS.Inference
    
    open Bistro.Controllers
    open Bistro.Controllers.Descriptor
    open Bistro.Controllers.Descriptor.Data
    open Bistro.Http
    
    open System.Text.RegularExpressions
    open System.Web
    
    module Controllers =
                
        //Home controller that handles any method and renders with home.django view         
        [<Bind("?"); RenderWith("Views/home.django"); ReflectedDefinition>]
        let defaultC (ctx: ictx) =  
            let Message = "Welcome to Bistro.FS!"
            Message
