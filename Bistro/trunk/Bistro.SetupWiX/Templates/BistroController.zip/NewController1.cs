﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Bistro.Controllers;
using Bistro.Controllers.Descriptor;
using Bistro.Controllers.Descriptor.Data;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractController
    {
        public override void DoProcessRequest(IExecutionContext context)
        {
            throw new NotImplementedException();
        }
    }
}
