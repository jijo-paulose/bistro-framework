﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate.Cfg;
using NHibernate;
using Bistro.Controllers;
using Bistro.Controllers.Descriptor;
using Bistro.Controllers.Descriptor.Data;
using BistroNHibernate.Entities;
using NHibernate.Tool.hbm2ddl;
using NHibernate.Criterion;

namespace BistroNHibernate.DataAccess.NHibernate
{
    /// <summary>
    /// Centralizes configuration of NHibernate-specific components
    /// </summary>
    public class NHibernateManager
    {
        private static NHibernateManager instance = new NHibernateManager();

        public static NHibernateManager Instance { get { return instance; } }

        Configuration config = new Configuration();

        ISessionFactory sessionFactory;

        public void Initialize()
        {
            config.Configure();
            config.SetProperty("current_session_context_class", "web");
            config.AddAssembly(typeof(Product).Assembly);
            sessionFactory = config.BuildSessionFactory();
            new SchemaExport(config).Execute(false, true, false);
            instance.Add(new Product { Name = "Apple", Category = "Fruits" });
        }

        public void Add(Product product)
        {
            using (ISession session = instance.GetNewSession())
            using (ITransaction transaction = session.BeginTransaction())
            {
                session.Save(product);
                transaction.Commit();
            }

        }
        public ICollection<Product> GetByCategory(string category)
        {
            using (ISession session = instance.GetNewSession())
            {
                var products = session
                    .CreateCriteria(typeof(Product))
                    .Add(Restrictions.Eq("Category", category))
                    .List<Product>();
                return products;
            }
        }

        /// <summary>
        /// Gets a new session.
        /// </summary>
        /// <returns></returns>
        public ISession GetNewSession()
        {
            return sessionFactory.OpenSession();
        }

        /// <summary>
        /// Gets the session factory.
        /// </summary>
        /// <returns></returns>
        public ISessionFactory GetFactory()
        {
            return sessionFactory;
        }

        /// <summary>
        /// Gets the current session.
        /// </summary>
        /// <returns></returns>
        public ISession GetSession()
        {
            return sessionFactory.GetCurrentSession();
        }
    }
}
