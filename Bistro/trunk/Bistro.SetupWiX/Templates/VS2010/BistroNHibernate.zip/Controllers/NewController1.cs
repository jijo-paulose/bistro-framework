﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Bistro.Controllers;
using Bistro.Controllers.Descriptor;
using Bistro.Controllers.Descriptor.Data;
using BistroNHibernate.DataAccess.NHibernate;
using NHibernate;
using BistroNHibernate.Entities;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;

namespace BistroNHibernate.Controllers
{
    /// <summary>
    /// Home controller. This controller services the 'get /home/index' method.
    /// </summary>
    [Bind("/index")]
    [RenderWith("Views/index.django")]
    public class HomeController : AbstractController
    {
        [Request]
        protected string Message = "Welcome to Bistro!";

        [Request]
        private ICollection<Product> products;
        /// <summary>
        /// Controller implementation.
        /// </summary>
        /// <param name="context">The context.</param>
        public override void DoProcessRequest(IExecutionContext context) { products = NHibernateManager.Instance.GetByCategory("Fruits"); }
    }

    /// <summary>
    /// Home controller. This controller services the 'get /home/index' method.
    /// </summary>
    [Bind("post /index/add")]
    [RenderWith("Views/index.django")]
    public class EditController : AbstractController
    {

        [Request]
        protected string Message = "Welcome to Bistro!";

        [Request]
        private ICollection<Product> products;

        [FormField, Request]
        protected string name;

        [FormField, Request]
        protected string category;

        /// <summary>
        /// Controller implementation.
        /// </summary>
        /// <param name="context">The context.</param>
        public override void DoProcessRequest(IExecutionContext context)
        {
            NHibernateManager.Instance.Add(new Product { Name = name, Category = category });
            products = NHibernateManager.Instance.GetByCategory("Fruits");
        }
    }
}
