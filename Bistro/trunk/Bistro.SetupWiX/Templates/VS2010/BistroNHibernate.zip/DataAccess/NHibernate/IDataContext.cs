﻿using System;
namespace BistroNHibernate.DataAccess.NHibernate
{
    public interface IDataContext : IDisposable
    {
        void Cleanup();
        void Setup();
    }
}
